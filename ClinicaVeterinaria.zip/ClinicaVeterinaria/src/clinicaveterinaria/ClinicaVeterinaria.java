/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clinicaveterinaria;

import clinicaveterinaria.ventanas.*;
import java.awt.*;
import javax.swing.border.AbstractBorder;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;


public class ClinicaVeterinaria extends JFrame  implements ActionListener {

    private Container container;
    private JButton loginButton, bi;
    private JLabel titleLabel;
    

    public ClinicaVeterinaria() {
        createAndShowGUI();
    }

  
    

    public class ThickBorder extends AbstractBorder{

        private int thickness;

        public ThickBorder(int thickness) {
            this.thickness = thickness;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setColor(Color.BLACK);
            g2d.setStroke(new BasicStroke(thickness));
            g2d.drawRoundRect(x, y, width - 1, height - 1, 20, 20);
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(thickness, thickness, thickness, thickness);
        }

        @Override
        public boolean isBorderOpaque() {
            return true;
        }

         
    }

     void createAndShowGUI() {
        
        setTitle("Clínica Veterinaria - Bienvenido");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        

        container = getContentPane();
        container.setLayout(null);
        container.setBackground(Color.WHITE);
      
       
        
        
        // Reemplaza "path/to/your/image.png" con la ruta de tu imagen
        String imagePath = "C:\\Users\\power\\Downloads\\image.png";
        ImageIcon icon = new ImageIcon(imagePath);
        JLabel imageLabel = new JLabel(icon);
        imageLabel.setSize(512, 512);
        imageLabel.setLocation(0, 495);
        container.add(imageLabel);

        titleLabel = new JLabel("Clínica Veterinaria");
        titleLabel.setFont(new Font("Bahnschrift SemiCondensed", Font.BOLD, 80));
        titleLabel.setSize(1920, 65);
        titleLabel.setLocation(0, 110);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        container.add(titleLabel);

        titleLabel = new JLabel("Bienvenido");
        titleLabel.setFont(new Font("Bahnschrift SemiCondensed", Font.BOLD, 60));
        titleLabel.setSize(1920, 60);
        titleLabel.setLocation(0,210);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        container.add(titleLabel);
        

        bi = new JButton("Iniciar Sesión");
        bi.setFont(new Font("Bahnschrift SemiCondensed", Font.PLAIN, 40));
        bi.setBackground(Color.decode("#000000"));
        bi.setForeground(Color.white);
        bi.setContentAreaFilled(true);
        bi.setSize(500, 60);
        bi.setLocation(710, 510);
        
        bi.addActionListener(this); 
        container.add(bi);
        
        
        
        
        //Accion para cambiar de ventana a traves de un boton (No lo toques bonola) 
        //ActionListener listener = (ActionEvent e) -> {
            //System.out.println("¡Has presionado el botón!");
            //setVisible(true);
        //}; 
        
        
        loginButton = new JButton("Registrarse");
        loginButton.setFont(new Font("Bahnschrift SemiCondensed", Font.PLAIN, 40));
        loginButton.setForeground(Color.black);
        loginButton.setContentAreaFilled(false);
        loginButton.setBorder(new ThickBorder(4));
        loginButton.setSize(500, 60);
        loginButton.setLocation(710, 710);
        
        loginButton.addActionListener(this); 
        container.add(loginButton);
        
        setVisible(true);
                
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==bi){
            Acceso p = new Acceso();
            p.setVisible(true);
            dispose();
        }
        if(e.getSource()==loginButton){
            Registro r = new Registro();
            r.setVisible(true);
        }
    }
    
   

    public static void main(String[] args) {
        new ClinicaVeterinaria();
    }
}
