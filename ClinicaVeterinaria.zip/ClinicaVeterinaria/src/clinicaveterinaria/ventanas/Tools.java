
package clinicaveterinaria.ventanas;


import javax.swing.JButton;
import java.awt.*;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

public class Tools {

    public  JButton BotonS (){ 
         JButton inicia = new JButton("");
         return inicia;
    }
    
    public JButton BotonS (String texto, int letra, Color ColorL, Color ColorF, int sizeX, int sizeY, int LocationX, int LocationY){
        JButton inicia = new JButton(texto);
        inicia.setFont(new Font("Bahnschrift SemiCondensed", Font.PLAIN, letra));
        inicia.setBackground(ColorL);
        inicia.setForeground(ColorF);
        inicia.setContentAreaFilled(true);
        inicia.setSize(sizeX, sizeY);
        inicia.setLocation(LocationX, LocationY);
        return inicia;
    }   
    
    public JButton BotonV(){
        JButton inicia = new JButton("");
         return inicia;
    }
    public JButton BotonV(String texto, int letra, Color ColorL,Color ColorF, int sizeX, int sizeY, int LocationX, int LocationY, int borde){
        JButton loginButton = new JButton(texto);
        loginButton.setFont(new Font("Bahnschrift SemiCondensed", Font.PLAIN, letra));
        loginButton.setForeground(ColorL);
        loginButton.setContentAreaFilled(false);
        loginButton.setBorder(new LineBorder(ColorF,borde));
        loginButton.setSize(sizeX, sizeY);
        loginButton.setLocation(LocationX, LocationY);
        
        return loginButton;
    }
    
    public JTextField TextField(){
        JTextField inicia = new JTextField();
        return inicia;
    }
    public JTextField TextField (int letra, Color ColorF, int sizeX, int sizeY, int LocationX, int LocationY, int borde){
        JTextField usuariot = new JTextField();
        usuariot.setBounds(LocationX, LocationY, sizeX, sizeY);
        usuariot.setFont(new Font("Bahnschrift SemiCondensed" , Font.BOLD, letra));
        usuariot.setBorder(new LineBorder(ColorF, borde)); 
        
        return usuariot;
    }
    
    public JLabel img (){
        JLabel imageLabel = new JLabel();
        return imageLabel;
    }
    
    public JLabel img (String img, int sizeX, int sizeY, int LocationX, int LocationY ){
        ImageIcon icon = new ImageIcon(img);
        JLabel imageLabel = new JLabel(icon);
        imageLabel.setSize(sizeX, sizeY);
        imageLabel.setLocation(LocationX, LocationY);
        return imageLabel;
    }
    
    public JLabel title (){
        JLabel titleLabel = new JLabel();
        return titleLabel;
    }
    public JLabel title (String texto, int letra,int sizeX, int sizeY, int LocationX, int LocationY){
        JLabel titleLabel = new JLabel(texto);
        titleLabel.setFont(new Font("Bahnschrift SemiCondensed", Font.BOLD, letra));
        titleLabel.setSize(sizeX, sizeY);
        titleLabel.setLocation(LocationX, LocationY);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        return titleLabel;
    }
    
     public JLabel titleMo (String texto, Font letra,int sizeX, int sizeY, int LocationX, int LocationY){
        JLabel titleLabel = new JLabel(texto);
        titleLabel.setFont(letra);
        titleLabel.setSize(sizeX, sizeY);
        titleLabel.setLocation(LocationX, LocationY);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        return titleLabel;
    }
     
    public JLabel titleMoD (String texto, Font letra,int sizeX, int sizeY, int LocationX, int LocationY){
        JLabel titleLabel = new JLabel(texto);
        titleLabel.setFont(letra);
        titleLabel.setSize(sizeX, sizeY);
        titleLabel.setLocation(LocationX, LocationY);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        return titleLabel;
    }
     
     public JPanel cuadro (Color color, int sizeX,int sizeY,int LocationX,int LocationY){
        JPanel panel = new JPanel();
        panel.setBackground(color);
        panel.setSize(sizeX, sizeY);
        panel.setLocation(LocationX, LocationY);
        panel.setLayout(null);
        return panel;
     }
     

     
  
}
