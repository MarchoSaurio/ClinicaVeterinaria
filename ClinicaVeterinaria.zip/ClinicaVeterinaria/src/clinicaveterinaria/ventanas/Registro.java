
package clinicaveterinaria.ventanas;

import clinicaveterinaria.ClinicaVeterinaria;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class Registro extends JFrame  implements ActionListener{
    
    private JButton reg;
    
    public Registro(){
        createAndShowGUI();
    }
    
    private void createAndShowGUI() {
        Tools t = new Tools();
        
        setTitle("Example");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        Container container = getContentPane();
        container.setLayout(null);
        container.setBackground(Color.WHITE);
        
        JLabel img = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\Registro.png", 512, 512, 1100, 300);
        container.add(img);
        
        JLabel revers = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\revers.png", 75, 75, 30, 20);
        container.add(revers);
        revers.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                ClinicaVeterinaria q = new ClinicaVeterinaria();
                q.setVisible(true);
                dispose();
            }
        });
        
        JLabel regis = t.title("Registro", 80, 1920, 100, 0, 40);
        container.add(regis);
        
        JLabel nom = t.title("Nombre",35,135,30,550,210);
        container.add(nom);
        JTextField nomt = t.TextField(35, Color.black, 370, 50, 550, 260, 3);
        container.add(nomt);
        
        JLabel tel = t.title("Telefono",35,145,30,550,350);
        container.add(tel);
        JTextField telt = t.TextField(35, Color.black, 370, 50, 550, 400, 3);
        container.add(telt);
        
        JLabel dir = t.title("Dirección",35,155,30,550,490);
        container.add(dir);
        JTextField dirt = t.TextField(35, Color.black, 370, 50, 550, 540, 3);
        container.add(dirt);
        
        JLabel usu = t.title("Nombre de Usuario",35,330,30,550,630);
        container.add(usu);
        JTextField usut = t.TextField(35, Color.black, 370, 50, 550, 680, 3);
        container.add(usut);
        
        JLabel con = t.title("Contraseña",35,190,30,550,770);
        container.add(con);
        
        JPasswordField password = new JPasswordField(10); 
        password.setBounds(550, 820, 370, 50);
        password.setFont(new Font("Bahnschrift SemiCondensed" , Font.BOLD, 35));
        password.setBorder(new LineBorder(Color.BLACK, 3));
        container.add(password);
        
        reg = t.BotonS("Registrarse", 35, Color.GRAY, Color.white, 370, 55, 550, 910);
        container.add(reg);
        reg.addActionListener(this); 
        
        setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==reg){
            Acceso p = new Acceso();
            p.setVisible(true);
            //dispose();
        }
    }
    
    
}
