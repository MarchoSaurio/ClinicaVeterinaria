package clinicaveterinaria.ventanas;

import clinicaveterinaria.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Quejas extends JFrame  implements ActionListener{
    
    private JButton reg;
    
    public Quejas(){
        createAndShowGUI();
    }
    
    private void createAndShowGUI() {
        Tools t = new Tools();
        
        setTitle("Example");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        Container container = getContentPane();
        container.setLayout(null);
        container.setBackground(Color.WHITE);
        
        //JLabel img = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\Quejas.png", 212, 212, 1100, 300);
        //container.add(img);
        
        JLabel revers = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\revers.png", 75, 75, 30, 20);
        container.add(revers);
        revers.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                Catalogo q = new Catalogo();
                q.setVisible(true);
                dispose();
            }
        });
        
        JLabel img = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\Quejas2.png", 150, 150, 1250, 600);
        container.add(img);

        
        
 

        
        JLabel regis = t.title("Quejas y Sugerencias", 60, 1920, 100, 0, 50);
        container.add(regis);
        
        JLabel tex = t.title("Agredecemos tus", 40, 580, 300, 1050,180);
        tex.setForeground(Color.GRAY);
        container.add(tex);
        JLabel tex2 = t.title("comentarios", 40, 580, 300, 1050,230);
        tex2.setForeground(Color.GRAY);
        container.add(tex2);
        
        JLabel texB = t.titleMo("Ayudanos a mejorar para poder brindarte", (new Font("Calibri", Font.ITALIC, 25)), 580, 200, 1050, 400);
        texB.setForeground(Color.GRAY);
        container.add(texB);
        
        JLabel texB2 = t.titleMo("un mejor servicio", (new Font("Calibri", Font.ITALIC, 25)), 580, 200, 1050, 430);
        texB2.setForeground(Color.GRAY);
        container.add(texB2);
        
        JLabel nom = t.title("Titulo",35,95,30,350,250);
        container.add(nom);
        JTextField nomt = t.TextField(35, Color.black, 470, 50, 350, 300, 3);
        container.add(nomt);
        
        JLabel tel = t.title("Descripcion",35,195,40,350,400);
        container.add(tel);
        JTextField telt = t.TextField(35, Color.black, 470, 350, 350, 450, 3);
        container.add(telt);
       
        JButton env = t.BotonS("Enviar", 35, Color.GRAY, Color.white, 470, 50, 350, 850);
        container.add(env);
        
        
        setVisible(true);
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==reg){
            Acceso p = new Acceso();
            p.setVisible(true);
            //dispose();
        }
    }
    
}
