package clinicaveterinaria.ventanas;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Catalogo extends JFrame  implements ActionListener{
    
    private JButton reg;
    private Color gris = new Color(222,227,232);
    
    public Catalogo(){
        createAndShowGUI();
    }
    
    private void createAndShowGUI() {
        Tools t = new Tools();
        
        setTitle("Example");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        Container container = getContentPane();
        container.setLayout(null);
        container.setBackground(Color.WHITE);
        
        //Header
        JLabel title = t.title("Catalogo de Servivios", 60, 1920, 90, 0, 20);
        container.add(title);
        
        JLabel inicio = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\inicioH.png",100,100,20,20);
        container.add(inicio);
        inicio.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                Acceso p = new Acceso();
                p.setVisible(true);
                dispose();
            }
        });
        
        JLabel catalogo = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\usuario.png",100,100,1780,10);
        container.add(catalogo);
        
        JLabel carrito = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\carrito.png",100,100,1650,10);
        container.add(carrito);
        carrito.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                Carrito p = new Carrito();
                p.setVisible(true);
                dispose();
            }
        });
        
        
        //Servicio 1 
        JPanel panel = t.cuadro(gris, 1000, 220, 460, 170);
        JLabel ser = t.title("Veterinario", 30, 1000, 50, 0 ,10);
        panel.add(ser);
        JLabel tex = t.titleMo("Ofrecemos consulta medica general a", (new Font("Calibri", Font.ITALIC, 25)), 420, 40, 80, 100);
        tex.setForeground(Color.black);
        panel.add(tex);
        JLabel tex2 = t.titleMo("tu mascota", (new Font("Calibri", Font.ITALIC, 25)), 150, 40, 80, 130);
        tex2.setForeground(Color.black);
        panel.add(tex2);
        JLabel precio = t.title("$650", 35, 100, 30, 650, 100);
        panel.add(precio);
        JButton agre = t.BotonS("Agregar", 18, Color.GRAY, Color.WHITE, 100, 35, 650, 150);
        panel.add(agre);
        JLabel img = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\veterinario.png", 135, 135, 810, 50);
        panel.add(img);
        
        container.add(panel);
   
        //Servicio 2
        JPanel panel2 = t.cuadro(gris, 1000, 220, 460, 430);
        JLabel ser2 = t.title("Estetica", 30, 1000, 50, 0 ,10);
        panel2.add(ser2);
        JLabel texB = t.titleMo("Ofrecemos el servicio de estetica para", (new Font("Calibri", Font.ITALIC, 25)), 420, 40, 80, 90);
        tex.setForeground(Color.black);
        panel2.add(texB);
        JLabel texB2 = t.titleMo("tu mascota el cual incluye baño,", (new Font("Calibri", Font.ITALIC, 25)), 360, 40, 80, 120);
        tex2.setForeground(Color.black);
        panel2.add(texB2);
        JLabel texB3 = t.titleMo("corte y limpieza dental", (new Font("Calibri", Font.ITALIC, 25)), 265, 40, 80, 150);
        tex2.setForeground(Color.black);
        panel2.add(texB3);
        JLabel precio2 = t.title("$400", 35, 100, 30, 650, 100);
        panel2.add(precio2);
        JButton agre2 = t.BotonS("Agregar", 18, Color.GRAY, Color.WHITE, 100, 35, 650, 150);
        panel2.add(agre2);
        JLabel img2 = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\ballo.png", 135, 135, 810, 50);
        panel2.add(img2);
        
        container.add(panel2);
        
        //Servicio 3
        JPanel panel3 = t.cuadro(gris, 1000, 220, 460, 690);
        JLabel ser3 = t.title("Guarderia", 30, 1000, 50, 0 ,10);
        panel3.add(ser3);
        JLabel texC = t.titleMo("Ofrecemos el servicio de guarderia para", (new Font("Calibri", Font.ITALIC, 25)), 420, 40, 80, 80);
        tex.setForeground(Color.black);
        panel3.add(texC);
        JLabel texC2 = t.titleMo("tu mascota (incluye alimento)", (new Font("Calibri", Font.ITALIC, 25)), 320, 40, 80, 110);
        tex2.setForeground(Color.black);
        panel3.add(texC2);
        JLabel texC3 = t.title("Precio por dia", 25, 180, 40, 80, 160);
        panel3.add(texC3);
        JLabel precio3 = t.title("$250", 35, 100, 30, 650, 100);
        panel3.add(precio3);
        JButton agre3 = t.BotonS("Agregar", 18, Color.GRAY, Color.WHITE, 100, 35, 650, 150);
        panel3.add(agre3);
        JLabel img3 = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\guarderia.png", 135, 135, 810, 50);
        panel3.add(img3);
        
        container.add(panel3);
        
        
       //Footer
       JLabel suge = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\suge.png",75,75,40,910);
       container.add(suge);
       suge.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                Quejas q = new Quejas();
                q.setVisible(true);
                dispose();
            }
        });
        
        setVisible(true);
    }
    
     
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==reg){
            Acceso p = new Acceso();
            p.setVisible(true);
            dispose();
        }
    }
    
    public static void main(String[] args) {
        new Catalogo();
    }
    
    
}
