package clinicaveterinaria.ventanas;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;


public class Carrito extends JFrame implements ActionListener {
    
    private Color gris = new Color(222,227,232);
    
    public Carrito(){
        createAndShowGUI();
    }
    
    private void createAndShowGUI() {
        Tools t = new Tools();
        
        setTitle("Example");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        Container container = getContentPane();
        container.setLayout(null);
        container.setBackground(Color.WHITE);
        
        //Header 
        JLabel title = t.title("Carrito de Servivios", 60, 1920, 90, 0, 20);
        container.add(title);
        
        JLabel inicio = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\inicioH.png",100,100,20,20);
        container.add(inicio);
        inicio.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                Acceso p = new Acceso();
                p.setVisible(true);
                dispose();
            }
        });
        
        JLabel usuario = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\usuario.png",100,100,1780,10);
        container.add(usuario);
        
        JLabel catalogo= t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\catalogo.png",100,100,1650,10);
        container.add(catalogo);
        catalogo.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                Catalogo p = new Catalogo();
                p.setVisible(true);
                dispose();
            }
        });
        
        
        //Body 
        JLabel tex = t.title("Carrito Vacio", 65, 1920, 60, 0, 320);
        tex.setForeground(Color.GRAY);
        container.add(tex);
        
        JLabel tex2 = t.titleMo("No se ha seleccionado ningun servicio", (new Font("Calibri", Font.ITALIC, 45)), 1920, 60, 0, 450);
        tex2.setForeground(Color.GRAY);
        container.add(tex2);
        
        JLabel img = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\cVacio.png", 150, 150, 885, 600);
        container.add(img);
        
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public static void main(String[] args) {
        new Carrito();
    }
}
