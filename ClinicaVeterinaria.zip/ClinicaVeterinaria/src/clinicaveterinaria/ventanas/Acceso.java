/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinicaveterinaria.ventanas;

import clinicaveterinaria.ClinicaVeterinaria;
import clinicaveterinaria.Pruebas;
import java.awt.*;
import javax.swing.border.AbstractBorder;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.border.LineBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Acceso extends JFrame  implements ActionListener {

    private Container container;
    private JButton loginButton, bi;
    private JLabel titleLabel;
    private JTextField usuariot;
    private JPasswordField password;

    public Acceso() {
        createAndShowGUI();
    }
      
    public class ThickBorder extends AbstractBorder{

        private int thickness;

        public ThickBorder(int thickness) {
            this.thickness = thickness;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setColor(Color.BLACK);
            g2d.setStroke(new BasicStroke(thickness));
            g2d.drawRoundRect(x, y, width - 1, height - 1, 20, 20);
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(thickness, thickness, thickness, thickness);
        }

        @Override
        public boolean isBorderOpaque() {
            return true;
        }

         
    }

    private void createAndShowGUI() {
        
        Tools t = new Tools ();
        
        setTitle("Example");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        

        container = getContentPane();
        container.setLayout(null);
        container.setBackground(Color.WHITE);
      
       

        String imagePath = "C:\\Users\\power\\Downloads\\Acceso.png";
        ImageIcon icon = new ImageIcon(imagePath);
        JLabel imageLabel = new JLabel(icon);
        imageLabel.setSize(512, 512);
        imageLabel.setLocation(420, 300);
        container.add(imageLabel);
        
        JLabel revers = t.img("C:\\Users\\power\\OneDrive\\Documentos\\IngenieriaSoftware\\img\\revers.png", 75, 75, 30, 20);
        container.add(revers);
        revers.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                ClinicaVeterinaria q = new ClinicaVeterinaria();
                q.setVisible(true);
            }
        });
        
        
        titleLabel = new JLabel("Acceso");
        titleLabel.setFont(new Font("Bahnschrift SemiCondensed", Font.BOLD, 80));
        titleLabel.setSize(1920, 65);
        titleLabel.setLocation(0, 70);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        container.add(titleLabel);
        
        JLabel usuario = new JLabel("Usuario");
        usuario.setFont(new Font("Bahnschrift SemiCondensed", Font.BOLD, 35));
        usuario.setSize(500, 30);
        usuario.setLocation(1050, 350);
        container.add(usuario);
        
        usuariot = new JTextField();
        usuariot.setBounds(1050, 400, 370, 50);
        usuariot.setFont(new Font("Bahnschrift SemiCondensed" , Font.BOLD, 35));
        usuariot.setBorder(new LineBorder(Color.BLACK, 3)); // Poner el colorjjk y el ancho del borde 
        //LengthRestrictedDocumentFilter.install(usuariot, 40); 
        container.add(usuariot);
        
        JLabel contra = new JLabel("Contraseña");
        contra.setFont(new Font("Bahnschrift SemiCondensed", Font.BOLD, 35));
        contra.setSize(500, 30);
        contra.setLocation(1050, 500);
        container.add(contra);
        
        //password 
        password = new JPasswordField(10); 
        password.setBounds(1050, 550, 370, 50);
        password.setFont(new Font("Bahnschrift SemiCondensed" , Font.BOLD, 35));
        password.setBorder(new LineBorder(Color.BLACK, 3));
 
        container.add(password);
        
        JButton inicia = t.BotonS("Iniciar Sesion", 35, Color.GRAY, Color.white, 370, 55, 1050, 680);
        inicia.addActionListener(this);
        container.add(inicia);
        
        
        setVisible(true);    
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String user = usuariot.getText();
        String contrasena = password.getText();
        Pruebas.verificar_credenciales(user, contrasena);
    }
   
}
