package clinicaveterinaria;

import clinicaveterinaria.ventanas.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Pruebas{
    public static void verificar_credenciales(String usuario_recibido, String contrasena_recibido) {
        boolean esCliente = esCliente(usuario_recibido, contrasena_recibido);
        boolean esEmpleado = esEmpleado(usuario_recibido, contrasena_recibido);
        boolean esVeterinario = esVeterinario(usuario_recibido);
        boolean esAdmin = esAdmin(usuario_recibido);

        if (esCliente) {
    abrirVentanaCliente();
} else if (esEmpleado && esVeterinario) {
    abrirVentanaVeterinario();
} else if (esEmpleado && esAdmin) {
    abrirVentanaAdmin();
} else {
    mostrarError();
}

    }

        private static boolean esCliente(String usuario, String contrasena) {
        boolean esCliente = false;
        String url = "jdbc:postgresql://localhost:5432/Clinica";
        String usuarioDB = "postgres";
        String contrasenaDB = "mars0123";

        try (Connection conexion = DriverManager.getConnection(url, usuarioDB, contrasenaDB)) {
            String consulta = "SELECT COUNT(*) > 0 AS es_cliente FROM Cliente WHERE Nombre_usuario = ? AND Contrasena = ?";
            try (PreparedStatement ps = conexion.prepareStatement(consulta)) {
                ps.setString(1, usuario);
                ps.setString(2, contrasena);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        esCliente = rs.getBoolean("es_cliente");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return esCliente;
    }
private static boolean esEmpleado(String usuario, String contrasena) {
    boolean esEmpleado = false;
    String url = "jdbc:postgresql://localhost:5432/Clinica";
    String usuarioDB = "postgres";
    String contrasenaDB = "mars0123";

    try (Connection conexion = DriverManager.getConnection(url, usuarioDB, contrasenaDB)) {
        String consulta = "SELECT COUNT(*) > 0 AS es_empleado FROM Empleados WHERE Nombre_usuario = ? AND Contrasena = ?";
        try (PreparedStatement ps = conexion.prepareStatement(consulta)) {
            ps.setString(1, usuario);
            ps.setString(2, contrasena);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    esEmpleado = rs.getBoolean("es_empleado");
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return esEmpleado;
}

private static boolean esVeterinario(String usuario) {
    boolean esVeterinario = false;
    String url = "jdbc:postgresql://localhost:5432/Clinica";
    String usuarioDB = "postgres";
    String contrasenaDB = "mars0123";

    try (Connection conexion = DriverManager.getConnection(url, usuarioDB, contrasenaDB)) {
        String consulta = "SELECT COUNT(*) > 0 AS es_veterinario FROM Empleados WHERE Nombre_usuario = ? AND id_puesto = 2";
        try (PreparedStatement ps = conexion.prepareStatement(consulta)) {
            ps.setString(1, usuario);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    esVeterinario = rs.getBoolean("es_veterinario");
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return esVeterinario;
}


    private static boolean esAdmin(String usuario) {
        boolean esAdmin = false;
        String url = "jdbc:postgresql://localhost:5432/Clinica";
        String usuarioDB = "postgres";
        String contrasenaDB = "mars0123";

        try (Connection conexion = DriverManager.getConnection(url, usuarioDB, contrasenaDB)) {
            String consulta = "SELECT COUNT(*) > 0 AS es_admin FROM Empleados WHERE Nombre_usuario = ? AND id_puesto = 1";
            try (PreparedStatement ps = conexion.prepareStatement(consulta)) {
                ps.setString(1, usuario);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        esAdmin = rs.getBoolean("es_admin");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return esAdmin; // Implementar lógica para verificar si es un admin
    }

    private static void abrirVentanaCliente() {
    System.out.println("Ventana Cliente...");
    Catalogo c = new Catalogo();
            c.setVisible(true);
}

    private static void abrirVentanaVeterinario() {
       System.out.println("Ventana Veterinario...");
    }

    private static void abrirVentanaAdmin() {
        
        System.out.println("Ventana Admin...");
    }

    private static void mostrarError() {
        
        System.out.println("Credenciales inválidas. Inténtalo de nuevo.");
    }
}
